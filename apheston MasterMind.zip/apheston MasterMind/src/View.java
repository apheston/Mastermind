import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class View {
	private static final int ROWS = 12;
	private int dw, dh, currentColor, currentRow;

	private Color colors[] = { Color.red,  Color.green,   Color.blue,
                             Color.cyan, Color.magenta, Color.yellow };

	private char letter[] = {'R','G','B','C','M','Y'};
	
	private Color guesses[][];
	private Color responses[][];

	private MastermindModel mm;
	private boolean displayAnswer;
	
	private int[] input = new int[4];private int[] bw = new int[2];

	/**
	 * Constructor for Mastermind View
	 * we need the Model to talk to.
	 * we need the reference to guesses and responses to
	 * paint the correct colors
	 */
	public View(MastermindModel m, Color guesses[][], Color responses[][])
	{
		this.mm = m;
		this.guesses = guesses;
		this.responses = responses;
	}

	/*
	 * this fills the grid with the correct colored pegs
	 * and fills the little 2 x 2 grid with the correct
	 * black and white pegs. Empty grid squares here are gray.
	 */
	public void fillBoard( Graphics g, int dw, int dh, int curRow ) {
		this.currentRow = curRow;
		
		//If all guesses have been exhausted
		if(currentRow >=12){	
			int[] ans = mm.getAnswer();
			//System.out.println(letter[ans[0]] + " " + letter[ans[1]] + " " + letter[ans[2]] + " " + letter[ans[0]]);
			
			for(int i=0; i < 4; i++){
				g.setColor(colors[ans[i]]);						
				g.fillRect((i+1)*dw, 0, dw, dh);
			}
		}
		
		//Draws the Responses
		
		for (int j = 0; j < 12; j++) {
			
			
			g.setColor(this.responses[j][0]);
			g.fillRect((5)*dw, (j+1)*dh, dw/2, dh/2);
			g.setColor(this.responses[j][1]);
			g.fillRect((5)*dw + (dw/2), (j+1)*dh, dw/2, dh/2);
			g.setColor(this.responses[j][2]);
			g.fillRect((5)*dw, (j+1)*dh + (dh/2), dw/2, dh/2);
			g.setColor(this.responses[j][3]);
			g.fillRect((5)*dw + (dw/2), (j+1)*dh +(dh/2), dw/2, dh/2);

		}
		
		/*
		int x=(res+1)*dw;
		int y = (res+1)*dh;
		g.fillRect((i+1)*dw, (j+1)*dh, dw, dh);
		*/				
		

		//Draws the guesses
		for (int i=0; i < 4; i++) {
			for (int j=0; j <  12; j++) {
				
				g.setColor(guesses[j][i]);
				if(curRow == j){
					g.setColor(colors[input[i]]);
				}
				g.fillRect((i+1)*dw, (j+1)*dh, dw, dh);
			}
		}
		
		/*
		// draw the black-white horizontal dividers
		for (int i=0; i < ROWS; i++) {
			g.drawLine( dw*5, (i+1)*dh+dh/2, dw*6, (i+1)*dh+dh/2 );  
		}
		// draw the black-white vertical divider
		g.drawLine( dw*5+dw/2, dh, dw*5+dw/2, dh*(ROWS+1) ); 
		 */
  	}

	/*
	 * draw the grids
	 */
	public void drawBoard( Graphics g, int dw, int dh ) {
		
		g.setColor( Color.black );
		
		// draw the rows
		for (int i=0; i < ROWS+1; i++) {
			g.drawLine( dw, dh*(i+1), 6*dw, dh*(i+1) );
		}
		// draw the columns
		for (int i=0; i <  6; i++) {
			g.drawLine( dw*(i+1), dh, dw*(i+1), (ROWS+1)*dh );
		}
		// draw the black-white horizontal dividers
		for (int i=0; i < ROWS; i++) {
			g.drawLine( dw*5, (i+1)*dh+dh/2, dw*6, (i+1)*dh+dh/2 );  
		}
		// draw the black-white vertical divider
		g.drawLine( dw*5+dw/2, dh, dw*5+dw/2, dh*(ROWS+1) );  

		// draw the color palette
		for (int i=0; i < 6; i++) {
			g.setColor( colors[i] );
			g.fillRect( i*dw+dw/2, dh*(ROWS+1)+dh/2, dw, dh );  
			//g.fillRect(x, y, width, height);
		}
	}

	public void setInput(int[] input) {
		this.input = input;
	}

	
	public static Color bwNext(int[] bw){
		if(bw[0] > 0){
			bw[0]--;
			return Color.BLACK;
		}
		if(bw[1] > 0){
			bw[1]--;
			return Color.WHITE;
		}
		return Color.GRAY;
	}
}
