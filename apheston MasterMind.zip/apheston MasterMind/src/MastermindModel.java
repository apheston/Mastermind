import java.util.Random;

public class MastermindModel {
	public static final int NUMBER_OF_POSITIONS = 4;
	public static final int MAXIMUM_VALUE = 5;

	private Random rn = new Random();
	private int[] answer = new int[NUMBER_OF_POSITIONS];
	private int answerSums[] = new int[MAXIMUM_VALUE+1];

	public MastermindModel() {
		/* create the random code for the user to guess */
		for (int i=0; i < answer.length; i++)
			answer[i] = rn.nextInt( answerSums.length );

		/* Initialize the answer housekeeping array */
		for (int i=0; i < answer.length; i++)
			answerSums[ answer[i] ]++;
	}

	/*
	 * this method evaluates the user's input and determines
	 * how many black & white pegs to place
	 */
	public void guess(int[] input, int[] bw ) {
		bw[0]=0;bw[1]=0;
		boolean[] inputChecked = {false,false,false,false};
		boolean[] answerChecked = {false,false,false,false};

		for(int x = 0; x < input.length; x++)
		{
			//check if black
			if(input[x] == answer[x] & (!inputChecked[x]) && (!answerChecked[x])){
				inputChecked[x]= true;
				answerChecked[x]=true;
				bw[0]++;
				if(bw[0]==4){
					input[0]=-3;
					return;
				}
			}
			//if not black, check if white
			else{
				for(int i = 0; i < input.length - 1; i++){
					for(int j = 0; j < answer.length - 1;j++){
						if((!inputChecked[i]) && (!answerChecked[j]) && (input[i] == answer[j])){
							inputChecked[i]= true;
							answerChecked[j]=true;
							bw[1]++;
						}
					}
				}
			}

			
		}
		
	//System.out.println("input" + IntegerToString(input) + " correct answer " + IntegerToString(answer) + " bw " + IntegerToString(bw));
	}

	public int[] getAnswer() {
		return answer;
	}
	
	
	public static String IntegerToString(int[] array){
		String str = "[";
		
		for(int x = 0; x < array.length - 1; x++){
			str = str + array[x] + " ";
		}
		str = str + array[array.length - 1] + "]";
		
		return str;
	}
}
