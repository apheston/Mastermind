import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import javax.swing.ImageIcon;
import java.awt.Image;

import javax.swing.*;

public class Mastermind extends Canvas implements MouseListener, ActionListener {
	private static final int ROWS = 12;
	/* display width and height */
	private int dw, dh, currentColor, currentRow;

	private Color colors[] = { Color.red,  Color.green,   Color.blue,
                             Color.cyan, Color.magenta, Color.yellow };

	/* the players guesses */
	private Color guesses[][] = new Color[ROWS][4];
	/* the programs responses */
	private Color responses[][] = new Color[ROWS][4];

	private int[] input = new int[4], bw = new int[2];

	private MastermindModel mm = new MastermindModel();
	private boolean displayAnswer;
	private View view;
	
	/**
	 * Constructor for Mastermind Controller
	 */
	public Mastermind() {
		reset();

		//by James Woolley and Alex Heston
		JFrame frame = new JFrame( "Mastermind" );
		/* exit if we close the window */
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		setBackground( Color.white );

		/* just one button to submit each guess */
		JButton submit = new JButton( "Submit guess" );
		submit.addActionListener( this );
		/* we need to know mouse coords to place colored pegs */
		addMouseListener( this );

		frame.getContentPane().add( this );
		/* put the button on the bottom of the frame */
		frame.getContentPane().add( submit, BorderLayout.SOUTH );

		frame.setSize( new Dimension( 220, 450 ) );
		frame.setVisible( true );

		view = new View(mm, guesses, responses);
		
		//Making our lives just a little bit easier :)
		//frame.setResizable(false);
		
        URL appIconUrl = getClass().getResource("Frogger.gif");
        ImageIcon appIcon = new ImageIcon(appIconUrl);
        frame.setIconImage(appIcon.getImage());
	}

	/**
	 * Called when the Submit Guess button is pressed.
	 */
	public void actionPerformed( ActionEvent e ) {
		if (e.getActionCommand().equals("Submit guess")) {
			
			if(currentRow >= ROWS){
				System.out.println("You have failed");
				this.reset();
				return;
			}
			else{
				//calculate guess
				mm.guess(input, bw);
				//if input[0]==-3 you win
				if(input[0]==-3){
					System.out.println("You've won!");
					this.reset();
					return;
				}
				//Fill in guess array
				for(int x = 0; x < input.length; x++){
					guesses[currentRow][x] = colors[input[x]];
				}
				//Fill in responses array
				int[] newbw = {bw[0],bw[1]};
				
				for(int x = 0; x <4;x++){
					if(newbw[0] > 0){
						responses[currentRow][x] = Color.BLACK;
						newbw[0]--;
					}
					else if(newbw[1] > 0){
						responses[currentRow][x] = Color.WHITE;
						newbw[1]--;
					}
					else{
						responses[currentRow][x] = Color.LIGHT_GRAY;
					}
				}
			}
			currentRow++;
		 } else {
			((JButton)e.getSource()).setText( "Submit guess" );
			reset();
		}
		repaint();
	}

	public void reset() {
		for (int i=0; i < ROWS; i++) {
			for (int j=0; j < 4; j++) {
				guesses[i][j] = Color.white;
				responses[i][j] = Color.DARK_GRAY;
			}
		}
		currentRow = 0;
		currentColor = 0;
		displayAnswer = false;
		
		this.repaint();
	}

	/**
	 * Called when the mouse button is pressed to select colors
	 * and to indicate which square to add a peg to
	 */
	public void mousePressed( MouseEvent e ) {
		/* get the x & y coords of the mouse position */
		int x = e.getX(), y = e.getY();
		
		int RightLimitX = (dw/2) + 5*dw+dw/2;
		int BottomLimitY = ( dh + dh*(ROWS+1)+dh/2);
		
		boolean xCorrect = ( (x> (dw/2)) && (x<RightLimitX));
		boolean yCorrect = ( (y> dh*(ROWS+1)+dh/2) && ( y < BottomLimitY) );
		
		if(xCorrect && yCorrect){
			for (int i=0; i < 6; i++) {
				int leftSide = i*dw+dw/2;
				int rightSide = (i+1)*dw+dw/2;
				if( (x > leftSide) && (x < rightSide) ){
					this.currentColor = i;
				}
			}			
		}
		
		if((x > dw)&&(x < 5*dw)&&(y > dh)&&(y < 13*dh)){
			for (int i=0; i < 4; i++) {
				int leftSide = dw*(1+i);
				int rightSide = dw*(2+i);
				
				if( (leftSide < x) && (x < rightSide) ){
					input[i] = currentColor; 
					view.setInput(input);
				}
			}
			
		}
		repaint();	
	}

	public void mouseEntered(  MouseEvent e ) { }

	public void mouseExited(   MouseEvent e ) { }

	public void mouseClicked(  MouseEvent e ) { }

	public void mouseReleased( MouseEvent e ) { }

	/* the paint method we need 
	 * remember we're a ContentPane here
	 * Don't call paint, call repaint instead
	 */
	public void paint( Graphics g ) {
		dw = (int) getSize().width / 7;
		dh = (int) getSize().height / (ROWS+3);
		view.fillBoard( g, dw, dh, currentRow );
		view.drawBoard( g, dw, dh );
	}
	
	public static void main( String[] args ) {
		new Mastermind();	
	}			
	
}
