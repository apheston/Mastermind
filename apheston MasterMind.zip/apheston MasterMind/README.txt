/******************************************************************************
 *  Name: Alex Heston
 *
 *  Partner Name: James Woolley
 *
 *  Date: Due 2/15/17
 *
 ******************************************************************************/
 
Which partner is submitting the program files?
 
Problem Set #5: MasterMind
 
Hours to complete assignment (optional):
7
 
 
/**********************************************************************
 *  Did you receive help from classmates, past CS 292 students, Red: NO
 *  Room tutors, or anyone else?  Please list their names: NO
 *  ("A Red Room tutor" or "Office hours on Thursday" is ok if you
 *  don't know their name.)
 **********************************************************************/
 
No
 
/**********************************************************************
 *  Describe any serious problems you encountered.
 **********************************************************************/
Putting the gridlines in the color representation of the answer.
 
Making the black, white, and grey boxes cooperate.`
 
/**********************************************************************
 *  List any other comments here.
 **********************************************************************/
 

